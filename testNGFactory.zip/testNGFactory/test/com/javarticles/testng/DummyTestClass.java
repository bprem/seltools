package com.javarticles.testng;

import org.testng.annotations.Test;

public class DummyTestClass {
    private String param;
    public DummyTestClass(String param) {
        this.param = param;
    }
    @Test
    public void dummyTest() {
        System.out.println("Param is " + param);
    }
}
