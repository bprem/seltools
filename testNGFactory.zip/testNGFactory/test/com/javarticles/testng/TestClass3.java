package com.javarticles.testng;

import org.testng.annotations.Test;

public class TestClass3 {
    @Test
    public void t() {
        System.out.println("TestClass3.t");
    }
}
