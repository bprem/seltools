package com.javarticles.testng;

import org.testng.annotations.Factory;
import org.testng.annotations.Test;

public class MultipleFactoryTest {
    private String param;

    public MultipleFactoryTest(String param) {
        this.param = param;
    }

    @Test
    public void t() {
        System.out.println("MultipleFactoryTest:t:" + param);
    }
    
    @Factory
    public Object[] create() {
        return new Object[] { new MultipleFactoryTest("Multiple factory test"), new TestClass1()};
    }
}
