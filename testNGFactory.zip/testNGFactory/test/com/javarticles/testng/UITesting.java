package com.javarticles.testng;

import org.testng.annotations.Factory;
import org.testng.annotations.Test;

public class UITesting {
    private String uiClient;
    
    public UITesting(String p) {
        this.uiClient = p;
    }

    @Test
    public void someTest() {
        System.out.println("someTest: " + uiClient);
    }
    
    @Factory
    public Object[] create() {
        return new Object[]{new UITesting("swing"), new UITesting("JSF"), new UITesting("web")};
    }
}
