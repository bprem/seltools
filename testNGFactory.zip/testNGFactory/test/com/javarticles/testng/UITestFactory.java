package com.javarticles.testng;

import org.testng.annotations.Factory;

public class UITestFactory {
    @Factory
    public static Object[] create() {
        return new Object[]{new UITesting("swing"), new UITesting("JSF"), new UITesting("web")};
    }
}
