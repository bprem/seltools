package testNGFactory;

import org.testng.TestNG;

import com.javarticles.testng.DummyTestClass;

public class TestNGRunConstructorWithParamExample {
    public static void main(String[] args) {
        TestNG testng = new TestNG();
        testng.setTestClasses(new Class[] { DummyTestClass.class });
        testng.run();
    }
}
