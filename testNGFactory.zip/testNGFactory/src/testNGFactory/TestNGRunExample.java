package testNGFactory;

import org.testng.TestNG;

import com.javarticles.testng.UITesting;

public class TestNGRunExample {
    public static void main(String[] args) {
        TestNG testng = new TestNG();
        testng.setTestClasses(new Class[] { UITesting.class });
        testng.run();
    }
}
